import streamlit as st
import pandas as pd
import plotly.express as px

# PAGE CONFIGURATION AND INITIALIZATION
# Setting up the fundamental layout and tab title for the browser.
# A wide layout is preferred to accommodate multiple charts side-by-side.

st.set_page_config(page_title="Financial Dashboard - Simone Miraglia", layout="wide")
st.title("📊 Financial Transactions Dashboard")


# DATA INGESTION AND PREPROCESSING
# The load_data function relies on the @st.cache_data decorator. 
# This ensures that the CSV is loaded only once per session, preventing 
# unnecessary reloads and significantly improving dashboard performance.

@st.cache_data
def load_data():
    df = pd.read_csv('dashboard_data.csv') 
    # Converting the raw string dates into pandas datetime objects 
    # to enable time-series filtering and aggregations.
    df['Date'] = pd.to_datetime(df['Date'])
    return df

df = load_data()


# INTERACTIVE SIDEBAR AND DYNAMIC FILTERING
# Implementing user controls to slice the dataset across multiple 
# dimensions (Time, Transaction Type, and Sector).

st.sidebar.header("🗓️ Filters")
default_start = pd.to_datetime("2024-01-01").date()
default_end = pd.to_datetime("2024-12-31").date()

# Date boundaries selector
date_range = st.sidebar.date_input(
    "Select a Date Range:",
    value=(default_start, default_end),
    min_value=default_start,
    max_value=default_end
)

st.sidebar.markdown("---")
# Using Streamlit's native color syntax to force the text to be blue directly in the code
st.sidebar.subheader(":blue[Advanced Filters]")

# Extracting unique transaction types dynamically to populate the multiselect widget
if 'TransactionType' in df.columns:
    transaction_types = df['TransactionType'].dropna().unique()
    selected_types = st.sidebar.multiselect(
        "Transaction Type:",
        options=transaction_types,
        default=transaction_types
    )
else:
    selected_types = []

# Extracting unique sectors dynamically
if 'sector' in df.columns:
    sectors = df['sector'].dropna().unique()
    selected_sectors = st.sidebar.multiselect(
        "Sectors:",
        options=sectors,
        default=sectors
    )
else:
    selected_sectors = []

# Applying the cumulative boolean mask to filter the main dataframe
if len(date_range) == 2:
    start_date, end_date = date_range
    mask = (df['Date'].dt.date >= start_date) & (df['Date'].dt.date <= end_date)
    
    if len(selected_types) > 0:
        mask = mask & (df['TransactionType'].isin(selected_types))
    if len(selected_sectors) > 0:
        mask = mask & (df['sector'].isin(selected_sectors))
        
    filtered_df = df.loc[mask]
else:
    filtered_df = df


# KEY PERFORMANCE INDICATORS 
# High-level summary metrics displayed at the top of the dashboard 
# to provide immediate contextual insights based on the applied filters.

st.markdown("### 📈 Key Performance Indicators (KPI)")
kpi1, kpi2, kpi3 = st.columns(3)

with kpi1:
    st.metric(label="Total Transactions", value=len(filtered_df))

with kpi2:
    if 'TransactionType' in filtered_df.columns:
        buy_count = len(filtered_df[filtered_df['TransactionType'] == 'BUY'])
        sell_count = len(filtered_df[filtered_df['TransactionType'] == 'SELL'])
        st.metric(label="BUY / SELL Ratio", value=f"{buy_count} / {sell_count}")
    else:
         st.metric(label="BUY / SELL Ratio", value="N/A")

with kpi3:
    if not filtered_df.empty and 'Symbol' in filtered_df.columns:
        top_asset = filtered_df['Symbol'].value_counts().index[0]
        st.metric(label="Most Traded Asset", value=top_asset)
    else:
        st.metric(label="Most Traded Asset", value="None")

st.divider()


# VISUAL ANALYTICS AND CHARTS
# Generating interactive Plotly charts. The data is grouped and 
# aggregated on the fly before being passed to the visualization layer.

st.subheader("Total Transactions Over Time")
time_data = filtered_df.groupby('Date').size().reset_index(name='Transaction Count')
fig1 = px.line(time_data, x='Date', y='Transaction Count', markers=True)
st.plotly_chart(fig1, use_container_width=True)

# Splitting the layout into two balanced columns for bar charts
col1, col2 = st.columns(2)

with col1:
    st.subheader("Top 3 Traded Symbols")
    top_symbols = filtered_df.groupby('Symbol').size().nlargest(3).reset_index(name='Count')
    fig2 = px.bar(top_symbols, x='Symbol', y='Count', color='Symbol')
    st.plotly_chart(fig2, use_container_width=True)

    st.subheader("Top 5 Sectors")
    if 'sector' in filtered_df.columns:
        top_sectors = filtered_df.groupby('sector').size().nlargest(5).reset_index(name='Count')
        fig3 = px.bar(top_sectors, x='sector', y='Count', color='sector')
        st.plotly_chart(fig3, use_container_width=True)

with col2:
    st.subheader("Top 5 Industries")
    if 'industry' in filtered_df.columns:
        top_industries = filtered_df.groupby('industry').size().nlargest(5).reset_index(name='Count')
        fig4 = px.bar(top_industries, x='industry', y='Count', color='industry')
        st.plotly_chart(fig4, use_container_width=True)


# ASSET LOOKUP
# A dedicated dictionary-like section to investigate specific entities.
# Users can search for a specific symbol or explore assets within a sector.

st.divider()
st.subheader("🔎 Asset Lookup")
st.markdown("Search the database to find specific metadata about assets or sectors.")

search_col1, search_col2 = st.columns(2)

with search_col1:
    if 'Symbol' in df.columns:
        all_symbols = sorted(df['Symbol'].dropna().unique())
        search_symbol = st.selectbox("Search by Symbol:", ["(Select a Symbol)"] + list(all_symbols))

        if search_symbol != "(Select a Symbol)":
            symbol_info = df[df['Symbol'] == search_symbol].iloc[0]
            st.write(f"**Sector:** {symbol_info.get('sector', 'N/A')}")
            st.write(f"**Industry:** {symbol_info.get('industry', 'N/A')}")
            st.write(f"**Country:** {symbol_info.get('Country', 'N/A')}")

with search_col2:
    if 'sector' in df.columns:
        all_sectors_search = sorted(df['sector'].dropna().unique())
        search_sector = st.selectbox("Search by Sector:", ["(Select a Sector)"] + list(all_sectors_search))

        if search_sector != "(Select a Sector)":
            sector_symbols = df[df['sector'] == search_sector]['Symbol'].unique()
            st.write(f"**Total distinct assets in {search_sector}:** {len(sector_symbols)}")
            symbols_list = ', '.join(sector_symbols[:10])
            if len(sector_symbols) > 10:
                symbols_list += "..."
            st.write(f"**Assets included:** {symbols_list}")


# RAW DATA EXPLORATION AND DOWNLOAD
# Interactive expander and CSV generation for filtered data extraction.
# This replaces the old checkbox with a cleaner, more professional interface.

st.divider()
st.subheader("📥 Export & Raw Data")

csv_data = filtered_df.to_csv(index=False).encode('utf-8')
st.download_button(
    label="Download Filtered Data (CSV)",
    data=csv_data,
    file_name='filtered_transactions.csv',
    mime='text/csv',
)

with st.expander("View latest 50 operations"):
    st.dataframe(filtered_df.sort_values(by='Date', ascending=False).head(50))